if (!window.hasRun) {
  window.hasRun = true;

  // Global o'zgaruvchilar
  let translations = {};
  let hoveredNode = null;
  let currentIndex = 0;
  let currentMatches = [];
  let translateResult = null;
  let quizIcon = null;
  let isNumLockOn = false;

  // Matnni tozalash funksiyasi
  const cleanText = (text) =>
    text
      .normalize("NFD")
      .replace(/[\u0300-\u036f]/g, "")
      .replace(/[.,\/#!$%\^&\*;:{}=\-_‘'"`~()]/g, "")
      .replace(/\s+/g, "")
      .toLowerCase();

  // Document.body yuklanishini kutish
  const waitForBody = (callback) => {
    if (document.body) return callback();
    const observer = new MutationObserver(() => {
      if (document.body) {
        observer.disconnect();
        callback();
      }
    });
    observer.observe(document.documentElement, { childList: true });
  };

  // Dinamik ::selection stilini qo'shish
  const updateSelectionStyle = () => {
    let styleElement = document.getElementById("dynamic-selection-style");
    if (!styleElement) {
      styleElement = document.createElement("style");
      styleElement.id = "dynamic-selection-style";
      document.head.appendChild(styleElement);
    }

    if (isNumLockOn) {
      styleElement.textContent = `
      ::selection {
        background: rgba(0, 119, 255, 0.04); /* Deyarli shaffof tanlov */
      }
    `;
    } else {
      styleElement.textContent = `
      ::selection {
        background: rgba(0, 120, 255, 0.5); /* Default tanlov rangi */
        color: #000;
      }
    `;
    }
  };

  // Key formani yaratish
  const createKeyForm = () => {
    const form = document.createElement("form");
    const input = document.createElement("input");
    input.type = "text";
    input.placeholder = "Keyni kiriting";
    form.appendChild(input);
    form.classList.add("subtle-form");
    input.classList.add("subtle-input");

    document.body.appendChild(form);
    input.focus();

    form.onsubmit = async (event) => {
      event.preventDefault();
      const keyInput = input.value.trim();
      if (!/^[a-zA-Z0-9_]+$/.test(keyInput)) return;

      try {
        const response = await fetch(
          `https://lazy-x-w5nx.onrender.com/read/cheats/${keyInput}`
        );
        if (!response.ok) throw new Error("Network response was not ok");
        translations = (await response.json()).translation;
        console.log("Translations loaded:", translations);
      } catch (error) {
        console.error("Error fetching translations:", error);
      }
    };

    document.addEventListener(
      "click",
      (event) => {
        if (!form.contains(event.target)) form.remove();
      },
      { once: true }
    );
  };

  // Gemini API orqali savol-javobni aniqlash
  const handleQuizRequest = async (
    selectedText,
    translateResult,
    retryCount = 0
  ) => {
    const MAX_RETRIES = 3;

    // Savol formatini tekshirish
    const quizPattern = /^(.+)\s*([\s\S]*)$/;
    const match = selectedText.match(quizPattern);
    if (!match) {
      translateResult.innerHTML =
        "Noto'g'ri savol formati. Quyidagi formatda kiriting:<br>savol?<br>javob1<br>javob2<br>javob3<br>javob4";
      translateResult.style.display = "block";
      return;
    }

    const [, question, answersText] = match;
    const answers = answersText
      .trim()
      .split("\n")
      .filter((answer) => answer.trim());
    if (answers.length !== 4) {
      translateResult.innerHTML = "To'rtta javob variantini kiriting.";
      translateResult.style.display = "block";
      return;
    }

    // Asosiy prompt
    let prompt = `Quyidagi savolning to'g'ri javobini topib, faqat a, b, c, yoki d shaklida qaytaring. Misol: "savol?\njavob1\njavob2\njavob3\njavob4"\n\n${selectedText}`;

    // Agar retry bo'lsa, aniqroq prompt
    if (retryCount > 0) {
      prompt = `Quyidagi savolning to'g'ri javobini topib, faqat a, b, c, yoki d harfini qaytaring (boshqa hech qanday matn yoki belgi qo'shmang):\n\n${selectedText}`;
    }

    try {
      const response = await fetch(
        "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=AIzaSyCRTX1mFJde9Or6MJ6_mb9aXk81XZTs6wk",
        {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            contents: [{ parts: [{ text: prompt }] }],
          }),
        }
      );

      if (!response.ok) throw new Error("Gemini API response was not ok");
      const data = await response.json();
      const result = data.candidates?.[0]?.content?.parts?.[0]?.text?.trim();

      if (!result || !["a", "b", "c", "d"].includes(result.toLowerCase())) {
        if (retryCount < MAX_RETRIES) {
          // Yangi prompt bilan qayta urinish
          return handleQuizRequest(
            selectedText,
            translateResult,
            retryCount + 1
          );
        } else {
          translateResult.innerHTML =
            "Gemini API dan to'g'ri javob formati olinmadi (maksimal urinishlar: 3).";
          translateResult.style.display = "block";
          return;
        }
      }

      // const answerIndex = { a: 0, b: 1, c: 2, d: 3 }[result.toLowerCase()];
      translateResult.innerHTML = result.toLowerCase();
      translateResult.style.display = "block";
    } catch (error) {
      console.error("Error fetching Gemini API:", error);
      translateResult.innerHTML =
        "Gemini API dan javob olishda xato yuz berdi.";
      translateResult.style.display = "block";
    }
  };

  // Xabar yuborish formasi
  const createMessageForm = () => {
    const form = document.createElement("form");
    const usernameInput = document.createElement("input");
    const messageInput = document.createElement("textarea");
    const submitButton = document.createElement("button");

    usernameInput.type = "text";
    usernameInput.placeholder = "Username";
    messageInput.placeholder = "Xabar";
    submitButton.textContent = "Yuborish";
    submitButton.type = "submit";

    form.append(usernameInput, messageInput, submitButton);
    form.classList.add("subtle-sender-form");
    usernameInput.classList.add("subtle-input");
    messageInput.classList.add("subtle-textarea");
    submitButton.classList.add("subtle-button");

    document.body.appendChild(form);
    usernameInput.focus();

    form.onsubmit = async (event) => {
      event.preventDefault();
      const username = usernameInput.value.trim();
      const message = messageInput.value.trim();

      if (!username || !message) return;

      try {
        const response = await fetch(
          `https://lazy-x-w5nx.onrender.com/send/users/${username}`,
          {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ questions: message }),
          }
        );
        if (!response.ok) throw new Error("Network response was not ok");
        console.log(await response.text());
        form.remove();
      } catch (error) {
        console.error("Error sending message:", error);
      }
    };
    document.addEventListener(
      "click",
      (event) => {
        if (!form.contains(event.target)) form.remove();
      },
      { once: true }
    );
  };

  // Tarjima ikonkasi va natija panelini yaratish
  const initializeTranslationUI = () => {
    const translateIcon = document.createElement("div");
    translateIcon.id = "translate-icon";
    // const translateResult = document.createElement("div");
    quizIcon = document.createElement("div"); // Yangi quiz-icon
    quizIcon.id = "quiz-icon";
    translateResult = document.createElement("div");
    translateResult.id = "translate-result";
    translateResult.className = "plabel";

    waitForBody(() => {
      document.body.append(translateIcon, quizIcon, translateResult);
    });

    return { translateIcon, quizIcon, translateResult };
  };

  // Tanlangan matnni tarjima qilish
  const translateText = (selectedText, translateResult) => {
    const cleanedText = cleanText(selectedText);
    const matches = Object.entries(translations).filter(([key]) =>
      cleanText(key).includes(cleanedText)
    );

    translateResult.innerHTML = matches.length
      ? matches.map(([_, value]) => `${value}<br>`).join("")
      : ".";
    translateResult.style.display = "block";
  };

  // Hover qilingan matnni tarjima qilish
  const handleTextTranslation = (e) => {
    const prevNumLockState = isNumLockOn;
    isNumLockOn = e.getModifierState("NumLock");
    if (prevNumLockState !== isNumLockOn) {
      updateSelectionStyle(); // NumLock holati o'zgarganda stilni yangilash
    }
    if (
      !translations ||
      !Object.keys(translations).length ||
      !hoveredNode?.innerText?.trim()
    )
      return;

    const hoveredText = hoveredNode.innerText.trim();
    const cleaned = cleanText(hoveredText);

    if (!hoveredNode.dataset.originalText) {
      hoveredNode.dataset.originalText = hoveredText;
    }

    currentMatches = Object.entries(translations).filter(([key]) =>
      cleanText(key).includes(cleaned)
    );

    if (currentMatches.length) {
      if (e.key === "CapsLock" && currentMatches.length > 1) {
        e.preventDefault();
        currentIndex = (currentIndex + 1) % currentMatches.length;
      }
      hoveredNode.innerText = currentMatches[currentIndex][1];
    } else {
      hoveredNode.innerText = hoveredNode.dataset.originalText;
      delete hoveredNode.dataset.originalText;
      currentMatches = [];
      currentIndex = 0;
    }
  };

  // Asosiy funksionallik
  (async () => {
    try {
      const { translateIcon, translateResult } = initializeTranslationUI();

      // Klaviatura hodisalari
      document.addEventListener("keyup", (e) => {
        if (e.key === "a" && e.altKey) {
          e.preventDefault();
          createKeyForm();
        } else if (e.key === "s" && e.altKey) {
          createMessageForm();
        } else if (e.key === "q" && e.altKey) {
          e.preventDefault();
          const selectedText = window.getSelection().toString().trim();
          if (selectedText) {
            handleQuizRequest(selectedText, translateResult);
          } else {
            translateResult.innerHTML =
              "Iltimos, savol va javob variantlarini tanlang.";
            translateResult.style.display = "block";
          }
        }
      });

      // Hover elementni aniqlash
      document.addEventListener("mousemove", (e) => {
        const elem = document.elementFromPoint(e.clientX, e.clientY);
        hoveredNode =
          elem?.childNodes.length === 1 &&
          elem.childNodes[0].nodeType === Node.TEXT_NODE
            ? elem
            : null;
      });

      // Ikki marta bosish va klaviatura hodisalari
      document.addEventListener("dblclick", handleTextTranslation);
      document.addEventListener("keydown", handleTextTranslation);

      // Tanlangan matnni ko'rsatish
      document.addEventListener("mouseup", (event) => {
        const selectedText = window.getSelection().toString().trim();
        if (!selectedText) {
          translateIcon.style.display = "none";
          translateResult.style.display = "none";
          return;
        }

        // Tanlov stilini yangilash (NumLock holatiga qarab)
        updateSelectionStyle();

        // Kursor pozitsiyasidan ikonlarni joylashtirish
        const cursorX = event.clientX;
        const cursorY = event.clientY;

        // translate-icon pozitsiyasi (kursorning o'ng pastki qismidan 10px pastga va o'ngga)
        translateIcon.style.top = `${window.scrollY + cursorY + 10}px`;
        translateIcon.style.left = `${window.scrollX + cursorX + 10}px`;
        translateIcon.style.display = "block";
        translateIcon.dataset.selectedText = selectedText;
        // translateIcon.style.opacity = isNumLockOn ? "0.1" : "1";

        // quiz-icon pozitsiyasi (translate-icon dan 25px o'ngga, kursorning o'ng pastki qismidan)
        quizIcon.style.top = `${window.scrollY + cursorY + 10}px`;
        quizIcon.style.left = `${window.scrollX + cursorX + 35}px`;
        quizIcon.style.display = "block";
        quizIcon.dataset.selectedText = selectedText;
        // quizIcon.style.opacity = isNumLockOn ? "0.1" : "0.2";

        // translateResult pozitsiyasi (tanlangan matnning yuqori qismida)
        const range = window
          .getSelection()
          .getRangeAt(0)
          .getBoundingClientRect();
        translateResult.style.top = `${
          window.scrollY + range.top - translateResult.offsetHeight - 10
        }px`;
        translateResult.style.left = `${window.scrollX + range.left}px`;
      });

      // Tarjima ikonkasiga bosish
      translateIcon.addEventListener("click", () => {
        const selectedText = translateIcon.dataset.selectedText;
        translateText(selectedText, translateResult);
        translateIcon.style.display = "none";
        quizIcon.style.display = "none"; // quiz-icon ni ham yashirish
      });

      // quiz-icon hodisasi
      quizIcon.addEventListener("click", () => {
        const selectedText = quizIcon.dataset.selectedText;
        handleQuizRequest(selectedText, translateResult);
        translateIcon.style.display = "none";
        quizIcon.style.display = "none";
      });

      // Tashqariga bosilganda yopish
      document.addEventListener("mousedown", (event) => {
        if (
          !translateIcon.contains(event.target) &&
          !quizIcon.contains(event.target) &&
          !translateResult.contains(event.target)
        ) {
          translateIcon.style.display = "none";
          quizIcon.style.display = "none";
          translateResult.style.display = "none";
        }
      });
    } catch (error) {
      console.error("Error initializing content script:", error);
    }
  })();
}
