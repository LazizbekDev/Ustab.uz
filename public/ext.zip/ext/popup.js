document.addEventListener("DOMContentLoaded", () => {
    const btn = document.getElementById("donate-button");
    if (btn) {
        btn.addEventListener("click", () => {
            chrome.tabs.create({
                url: "https://tirikchilik.uz/lazy",
            });
        });
    }
});
